create database ManagementStore;

use ManagementStore;

create table Costumer(
CodID int primary key identity (1,1),
Name varchar (50) not null,
LastName varchar (50) not null,
Gender char (6) not null,
Mail varchar (50) not null,
Phone varchar (20) not null)


create table SalesorderHeader(
OrderID int primary key identity (1,1),
OrderDate date not null,
CostumerID int not null, 
SalesAmount float not null,
foreign key (CostumerID) references Costumer (CodID))

create table Salesorderdetail(
OrderID int,
GameID int,
Amount float not null,
primary key (OrderID,GameID),
foreign key (OrderID) references SalesorderHeader (OrderID))

create table VideoGames(
GameID int primary key identity (1,1),
Name varchar (50) not null,
NameDeveloper varchar (50) not null,
DistribuitionDate date not null,
Price float not null,
Category varchar (50) not null)

alter table Salesorderdetail 
add foreign key (GameID) 
references  VideoGames (GameID);

create table Positiongames(
StoreID int,
GameID int,
SectorName varchar(50) not null,
NumberCopy int not null,
primary key (StoreID,GameID),
foreign key (GameID) references Videogames (GameID))

create table Store(
StoreID int primary key identity (1,1),
Storename varchar(50) not null,
Address varchar (50) not null,
City varchar(50) not null,
Phone varchar(50) not null)

alter table Positiongames
add foreign key (StoreID) references Store (StoreID);

create table Career(
StoreID int,
CDF varchar (50),
Startdate date not null,
Enddate date not null,
Position varchar (50),
primary key (StoreID,CDF),
foreign key (StoreID) references Store (StoreID))

create table Employee(
CDF varchar (50) primary key,
Name varchar( 50)not null, 
LastName varchar(50)not null,
Degree varchar(50)not null,
Phone varchar (50) not null)

alter table Career
add foreign key (CDF) references Employee (CDF);

insert into Costumer(Name,LastName,Gender,Mail,Phone) values ('Nanni','Cascio','M','nannicascio@live.it','3389756453')