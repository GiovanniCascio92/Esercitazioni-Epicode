/* ESERCIZIO EPICODE

1
SELECT Citt�, NumPiste 
FROM Aeroporto
WHERE NumPiste= null

2
SELECT TipoAereo, CittaPart
FROM Volo
WHERE CittaPart= 'Torino'

3
SELECT CittaPart, CittaArriv
FROM Volo
WHERE CittaArriv= 'Bologna'

4
SELECT IDVolo, CittaPart, CittaArriv
FROM Volo
WHERE IDVolo= 'AZ346'

5
SELECT TipoAereo, GiornoSett, OraPart, CittaPart, CittaArriv
FROM Volo
WHERE CittaPart LIKE 'B%' AND CittaArriv LIKE 'A%'

*/