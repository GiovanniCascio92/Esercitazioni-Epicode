create table Scuola (
ID int identity (1,1),
Nome varchar(25),
Citt� varchar(25),
Indirizzo varchar(25),
Tipologia varchar(25),
constraint PK_Scuola_ID primary key (ID))

create table Contratto (
ID int identity(1,1),
IDScuola int,
IDDocente int,
DataInizio date,
DataFine date,
constraint PK_Contratto_IDContratto primary key (ID),
constraint FK_Contratto_IDScuola foreign key (IDScuola)
references Scuola (ID))



create table Docente (
ID int identity (1,1),
Nome varchar(25),
Cognome varchar(25),
Email varchar(25),
Genere varchar(25),
Telefono varchar(25),
constraint PK_Docente_ID primary key (ID))

alter table Contratto add constraint FK_Contratto_Docente foreign key (IDDocente) 
references Docente (ID);


create table Materia (
ID int identity (1,1),
IDContratto int,
IDClasse int,
Nome varchar(25),
constraint FK_Materia_IDContratto foreign key (IDContratto)
references Contratto (ID))

create table Aula (
ID int identity (1,1),
Piano int,
NumeroAula int,
Capienza int,
IDScuola int,
constraint PK_Aula_ID primary key (ID),
constraint FK_Aula_Scuola foreign key (IDScuola)
references Scuola (ID))

create table Classe (
ID int identity (1,1),
Sezione varchar(25),
Anno int,
AnnoScolastico int,
IDAula int,
constraint PK_Classe_ID primary key (ID),
constraint FK_Classe_Aula foreign key (IDAula)
references Aula (ID))

alter table Materia add constraint FK_Materia_Classe foreign key (IDClasse) 
references Classe (ID);

create table Alunno (
Matricola int identity (1000,1),
Nome varchar(25),
Cognome varchar(25),
Datadinascita date,
Telefono varchar(25),
Indirizzo varchar(25),
IDClasse int,
constraint FK_Alunno_IDClasse foreign key (IDClasse)
references Classe (ID))

/*Insert data*/


insert into Scuola(Nome, Citt�, Indirizzo, Tipologia) values ('Verona Trento','Messina','Via ugo bassi n�12','Industriale');
insert into Scuola(Nome, Citt�, Indirizzo, Tipologia) values ('Maurolico','Messina','Via primo settembre n�13','Liceo Classico');
insert into Scuola(Nome, Citt�, Indirizzo, Tipologia) values ('La Farina','Messina','Via Roma n� 8','Liceo Classico');
insert into Scuola(Nome, Citt�, Indirizzo, Tipologia) values ('Jaci','Messina','Via cesare battisti n� 23','Commerciale');
insert into Scuola(Nome, Citt�, Indirizzo, Tipologia) values ('Minutoli','Messina','Via Zenone n� 15','Geometra');
insert into Scuola(Nome, Citt�, Indirizzo, Tipologia) values ('Basile','Messina','Via Palermo n�23','Liceo Artistico');
insert into Scuola(Nome, Citt�, Indirizzo, Tipologia) values ('Seguenza','Messina','Via del popolo n� 16','Liceo scientifico');


insert into Docente(Nome, Cognome, Email, Genere, Telefono) values ('Mario','Rossi','MarioRossi@gmail.com','Uomo', '3485645638');
insert into Docente(Nome, Cognome, Email, Genere, Telefono) values ('Giuseppe','Verdi','Giuseppeverdi@gmail.com','Uomo', '3387652934');
insert into Docente(Nome, Cognome, Email, Genere, Telefono) values ('Lucia','De salvo','mariadesalvo@gmail.com','Donna', '3458249076');
insert into Docente(Nome, Cognome, Email, Genere, Telefono) values ('Gabriella','Marrono', 'gabriellamar@gmail.com','Donna', '8734256498');
insert into Docente(Nome, Cognome, Email, Genere, Telefono) values ('Rosaria','Maria','rosariamaria@gmail.com','Donna', '7863245327');
insert into Docente(Nome, Cognome, Email, Genere, Telefono) values ('Giovanni','Messina','giovannime@hotmail.com','Uomo', '3456798765');
insert into Docente(Nome, Cognome, Email, Genere, Telefono) values ('Gioele','Genova','gioelegenova@hotmail.com','Uomo', '3334587908');


insert into Contratto(IDScuola, IDDocente, DataInizio, DataFine) values ('1','2','08/09/2020','09/05/2022');
insert into Contratto(IDScuola, IDDocente, DataInizio, DataFine) values ('2','6','01/04/2019','01/09/2022');
insert into Contratto(IDScuola, IDDocente, DataInizio, DataFine) values ('3','5','09/03/2018','12/02/2022');
insert into Contratto(IDScuola, IDDocente, DataInizio, DataFine) values ('4','4','10/09/2017','01/07/2021');
insert into Contratto(IDScuola, IDDocente, DataInizio, DataFine) values ('5','1','04/07/2016','24/01/2023');
insert into Contratto(IDScuola, IDDocente, DataInizio, DataFine) values ('6','7','12/04/2022','12/09/2023');
insert into Contratto(IDScuola, IDDocente, DataInizio, DataFine) values ('7','3','15/09/2021','01/09/2023');
insert into Contratto(IDScuola, IDDocente, DataInizio, DataFine) values ('1','6','01/10/2022','12/12/2024');
insert into Contratto(IDScuola, IDDocente, DataInizio, DataFine) values ('2','2','13/06/2022','14/08/2024');
insert into Contratto(IDScuola, IDDocente, DataInizio, DataFine) values ('3','1','29/01/2023','15/08/2025');
insert into Contratto(IDScuola, IDDocente, DataInizio, DataFine) values ('4','3','04/09/2023','05/09/2026');
insert into Contratto(IDScuola, IDDocente, DataInizio, DataFine) values ('5','5','25/01/2023','28/08/2025');
insert into Contratto(IDScuola, IDDocente, DataInizio, DataFine) values ('6','7','14/09/2023','08/07/2024');
insert into Contratto(IDScuola, IDDocente, DataInizio, DataFine) values ('7','4','02/07/2021','27/07/2022');
insert into Contratto(IDScuola, IDDocente, DataInizio, DataFine) values ('2','4','13/08/2022','14/08/2024');


insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('1','01','22','1');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('1','02','22','1');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('2','03','25','1');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('2','04','25','1');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','05','25','1');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','06','22','1');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('1','01','22','2');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('1','02','20','2');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('2','03','25','2');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('2','04','23','2');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','05','23','2');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','06','24','2');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','07','24','2');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('1','02','20','3');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('2','03','25','3');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('2','04','23','3');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','05','20','3');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','06','23','3');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','07','27','3');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('1','02','20','4');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('2','03','25','4');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('2','04','23','4');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','05','23','4');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','06','23','4');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','07','24','4');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('1','02','30','5');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('2','03','25','5');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('2','04','23','5');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','05','23','5');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','06','24','5');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','07','29','5');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('1','02','20','6');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('2','03','25','6');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('2','04','23','6');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','05','26','6');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','06','24','6');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','07','24','6');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('1','02','30','7');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('2','03','25','7');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('2','04','28','7');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','05','23','7');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','06','26','7');
insert into Aula(Piano, NumeroAula, Capienza, IDScuola) values ('3','07','24','7');


insert into Classe(Sezione, Anno, AnnoScolastico, IDAula) values ('B','5','2020', '1');
insert into Classe(Sezione, Anno, AnnoScolastico, IDAula) values ('A','3','2020', '8');
insert into Classe(Sezione, Anno, AnnoScolastico, IDAula) values ('C','4','2020', '12');
insert into Classe(Sezione, Anno, AnnoScolastico, IDAula) values ('A','2','2021', '18');
insert into Classe(Sezione, Anno, AnnoScolastico, IDAula) values ('B','4','2021', '24');
insert into Classe(Sezione, Anno, AnnoScolastico, IDAula) values ('C','1','2021', '29');
insert into Classe(Sezione, Anno, AnnoScolastico, IDAula) values ('D','2','2022', '34');
insert into Classe(Sezione, Anno, AnnoScolastico, IDAula) values ('A','5','2022', '40');
insert into Classe(Sezione, Anno, AnnoScolastico, IDAula) values ('B','4','2022', '5');
insert into Classe(Sezione, Anno, AnnoScolastico, IDAula) values ('C','4','2023', '14');
insert into Classe(Sezione, Anno, AnnoScolastico, IDAula) values ('D','3','2023', '25');
insert into Classe(Sezione, Anno, AnnoScolastico, IDAula) values ('A','2','2023', '33');
insert into Classe(Sezione, Anno, AnnoScolastico, IDAula) values ('B','1','2023', '10');


insert into Materia(IDClasse, IDContratto, Nome) values ('1','1','Matematica');
insert into Materia(IDClasse, IDContratto, Nome) values ('9','8','Italiano');
insert into Materia(IDClasse, IDContratto, Nome) values ('2','2','Informatica');
insert into Materia(IDClasse, IDContratto, Nome) values ('3','9','Scienze');
insert into Materia(IDClasse, IDContratto, Nome) values ('4','10','Storia');
insert into Materia(IDClasse, IDContratto, Nome) values ('5','4','Matematica');
insert into Materia(IDClasse, IDContratto, Nome) values ('6','5','Inglese');
insert into Materia(IDClasse, IDContratto, Nome) values ('7','6','Francese');
insert into Materia(IDClasse, IDContratto, Nome) values ('8','7','Italiano');
insert into Materia(IDClasse, IDContratto, Nome) values ('9','8','Diritto');
insert into Materia(IDClasse, IDContratto, Nome) values ('10','10','Scienze');
insert into Materia(IDClasse, IDContratto, Nome) values ('11','11','Storia');
insert into Materia(IDClasse, IDContratto, Nome) values ('12','13','Matematica');
insert into Materia(IDClasse, IDContratto, Nome) values ('13','14','Italiano');



insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Maria','Raffa','09/10/2007', '3456780432', 'Via Giasone n 7', '13');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Teresa','Costa','10/08/2007', '3335892569', 'Via Ditone n 8', '11');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Erminda','Ardizzone','01/05/2006', '3339876542', 'Via Giovane n 11', '10');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Sally','Strano','26/08/2005', '3938344567', 'Via Teodoro n 34', '9');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Scar','Strano','12/07/2006', '3334589567', 'Via Tritone n 4', '6');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Simba','Strano','29/05/2007', '3312986532', 'Via Roma n 24', '5');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Andrea','Cascio','04/04/2007', '3336802341', '	Via Giacomo Battisti n 4', '4');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Mattia','Rossi','22/06/2005', '3456723156', 'Via Garibaldi n 7', '7');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Mario','Cutugno','15/08/2007', '3398754367', 'Via Frosinone n 34', '12');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Giovanni','Costa','18/01/2007', '3284456789', 'Via Giacomo Leopardi n 3', '3');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Mariann','DeSalvo','07/01/2007', '3332145908', 'Via Selmone n 10', '2');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Mario','Gentile','24/01/2006', '3339087123', 'Via Piazza n 4', '1');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Santina','Laguidara','27/02/2005', '3455643789', 'Via Torino n 8', '8');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Marge','Simpson','27/02/2005', '3455443789', 'Via springfield', '8');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Kim','Kardashian','27/02/1992', '3455643789', 'Via Hollywood', '2');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Giovanni','Scotti','27/02/2005', '3455643789', 'Via della soia', '2');
insert into Alunno(Nome, Cognome, Datadinascita, Telefono, Indirizzo, IDClasse) values ('Emma','Watson','27/02/2005', '3455633789', 'Via Hogwarts', '8');



/*Query*/

/*Numero di studenti per ogni classe*/

Select classi.ID as idClasse, count(*) as numStud 
from dbo.Classe as classi
inner join dbo.Alunno as studenti
on  classi.ID = studenti.IDClasse
group by classi.ID;

/*Numero di docenti uomini e donne in un determinato anno scolastico (2022-2023)*/

select docente.Genere, count(*)
from dbo.Docente as docente 
inner join dbo.Contratto as contratto
on docente.ID = contratto.IDDocente
group by docente.Genere

/*Elenco docenti che hanno lavorato in una determinata scuola (Verona Trento) in un determinato anno (2022)*/

select docente.Nome, docente.Cognome, Scuola.Nome
from (dbo.Scuola as scuola 
inner join dbo.Contratto as contratto
on scuola.ID = contratto.IDScuola) 
inner join dbo.Docente as docente 
on contratto.IDDocente = docente.ID
where scuola.Nome = 'Verona Trento' and Year(contratto.DataInizio) <= '2022' and Year(contratto.DataFine) >= '2022' 

/*Elenco del numero di docenti che insegnano una determinata materia per ogni scuola*/

select scuola.Nome, materia.Nome, count(*)
from (dbo.Scuola as scuola 
inner join dbo.Contratto as contratto
on scuola.ID = contratto.IDScuola) 
inner join dbo.Materia as materia 
on contratto.ID = materia.IDContratto
group by scuola.Nome, materia.Nome

/*Elenco di materie studiate da un determinato alunno (Sally Strano)*/

select materia.Nome
from (dbo.Materia as materia
inner join dbo.Classe as classe
on materia.IDClasse = classe.ID)
inner join dbo.Alunno as studente 
on classe.ID = studente.IDClasse
where studente.Nome = 'Sally' and studente.Cognome = 'Strano'

/*Elenco studenti di una determinata sezione (B)*/

select classe.Sezione, classe.Anno, studente.Nome, studente.Cognome
from dbo.Classe as classe 
inner join dbo.Alunno as studente 
on classe.ID = studente.IDClasse
where classe.Sezione = 'B'
order by studente.Cognome

/*Calcola la capienza massima di studenti in ogni scuola*/

select scuola.Nome, sum(aula.Capienza) as capienzaMAX
from dbo.Scuola as scuola
inner join dbo.Aula as aula
on scuola.ID = aula.IDScuola
group by scuola.Nome
order by capienzaMAX desc

/*Quante aule ci sono per piano in ogni scuola*/

select scuola.Nome, aula.Piano, count (*)
from dbo.Scuola as scuola
inner join  dbo.Aula as aula
on scuola.ID = aula.IDScuola
group by scuola.Nome, aula.Piano
order by scuola.Nome, aula.Piano

/*Docenti che non hanno un contratto attivo in questo momento*/

select *
from(select docente.Nome, docente.Cognome ,max(contratto.DataFine) as prova
from dbo.Docente as docente 
inner join dbo.Contratto as contratto
on docente.ID = contratto.IDDocente
group by docente.Nome, docente.Cognome) as table1
where prova < getdate()

/*Numero di alunni di ogni scuola in un determinato anno (2023)*/

select scuola.Nome, count(studente.Matricola) as numStudente, classe.AnnoScolastico
from (((dbo.Scuola as scuola 
inner join dbo.Aula as aula
on scuola.ID = aula.IDScuola)
inner join dbo.Classe as classe
on aula.ID = classe.IDAula)
inner join dbo.Alunno as studente
on classe.ID = studente.IDClasse)
group by scuola.Nome, classe.AnnoScolastico
having classe.AnnoScolastico = 2023







